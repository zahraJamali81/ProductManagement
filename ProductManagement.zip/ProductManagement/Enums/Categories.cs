﻿namespace ProductManagement.Enums
{
    public enum Categories
    {
        Category1,
        Category2,
        Category3
    }
}
